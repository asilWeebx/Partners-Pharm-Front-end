from rest_framework import serializers
from .models import Product, Category

class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ['id', 'name', 'name_ru', 'name_en', 'slug']


class ProductSerializer(serializers.ModelSerializer):
    category_name = serializers.CharField(source='category.name', read_only=True)
    
    class Meta:
        model = Product
        fields = [
            'id', 'code', 'category', 'category_name',
            'name', 'name_ru', 'name_en',
            'description', 'description_ru', 'description_en',
            'image', 'is_active', 'featured',
            'created_at', 'updated_at'
        ]
        read_only_fields = ['created_at', 'updated_at']
