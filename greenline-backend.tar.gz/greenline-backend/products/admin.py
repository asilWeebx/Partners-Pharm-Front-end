from django.contrib import admin
from .models import Product, Category

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name', 'slug', 'created_at']
    prepopulated_fields = {'slug': ('name',)}
    search_fields = ['name', 'name_ru', 'name_en']


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ['code', 'name', 'category', 'is_active', 'featured', 'created_at']
    list_filter = ['category', 'is_active', 'featured', 'created_at']
    search_fields = ['code', 'name', 'name_ru', 'name_en', 'description']
    list_editable = ['is_active', 'featured']
    readonly_fields = ['created_at', 'updated_at']
    
    fieldsets = (
        ('Basic Information', {
            'fields': ('code', 'category', 'image')
        }),
        ('Uzbek Content', {
            'fields': ('name', 'description')
        }),
        ('Russian Content', {
            'fields': ('name_ru', 'description_ru'),
            'classes': ('collapse',)
        }),
        ('English Content', {
            'fields': ('name_en', 'description_en'),
            'classes': ('collapse',)
        }),
        ('Status', {
            'fields': ('is_active', 'featured')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )
