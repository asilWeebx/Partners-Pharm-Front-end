from django.db import models

class Disease(models.Model):
    # Multilingual Titles
    title = models.CharField(max_length=200)  # Uzbek
    title_ru = models.CharField(max_length=200, blank=True)
    title_en = models.CharField(max_length=200, blank=True)
    
    # Multilingual Products Description
    products = models.TextField(help_text="Comma-separated product names")  # Uzbek
    products_ru = models.TextField(blank=True)
    products_en = models.TextField(blank=True)
    
    # Status
    is_active = models.BooleanField(default=True)
    order = models.IntegerField(default=0)
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['order', 'title']
        
    def __str__(self):
        return self.title
