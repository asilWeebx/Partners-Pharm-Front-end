from django.contrib import admin
from .models import Disease

@admin.register(Disease)
class DiseaseAdmin(admin.ModelAdmin):
    list_display = ['title', 'is_active', 'order', 'created_at']
    list_filter = ['is_active', 'created_at']
    search_fields = ['title', 'title_ru', 'title_en', 'products']
    list_editable = ['is_active', 'order']
    readonly_fields = ['created_at', 'updated_at']
    
    fieldsets = (
        ('Uzbek Content', {
            'fields': ('title', 'products')
        }),
        ('Russian Content', {
            'fields': ('title_ru', 'products_ru'),
            'classes': ('collapse',)
        }),
        ('English Content', {
            'fields': ('title_en', 'products_en'),
            'classes': ('collapse',)
        }),
        ('Settings', {
            'fields': ('is_active', 'order')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )
