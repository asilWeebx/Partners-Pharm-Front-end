from rest_framework import serializers, viewsets
from rest_framework.permissions import IsAuthenticatedOrReadOnly
from .models import Disease

class DiseaseSerializer(serializers.ModelSerializer):
    class Meta:
        model = Disease
        fields = [
            'id', 'title', 'title_ru', 'title_en',
            'products', 'products_ru', 'products_en',
            'is_active', 'order',
            'created_at', 'updated_at'
        ]
        read_only_fields = ['created_at', 'updated_at']


class DiseaseViewSet(viewsets.ModelViewSet):
    queryset = Disease.objects.filter(is_active=True)
    serializer_class = DiseaseSerializer
    permission_classes = [IsAuthenticatedOrReadOnly]
    ordering = ['order', 'title']
