#!/bin/bash

# Django Backend Setup Script

echo "🚀 Setting up GreenLine Django Backend..."

# Create virtual environment
python3 -m venv venv

# Activate virtual environment
source venv/bin/activate

# Install dependencies
pip install --upgrade pip
pip install -r requirements.txt

# Create Django project
django-admin startproject config .

# Create apps
python manage.py startapp products
python manage.py startapp partners
python manage.py startapp diseases

echo "✅ Django backend setup complete!"
echo "📝 Next steps:"
echo "   1. source venv/bin/activate"
echo "   2. Update config/settings.py"
echo "   3. python manage.py makemigrations"
echo "   4. python manage.py migrate"
echo "   5. python manage.py createsuperuser"
echo "   6. python manage.py runserver"
