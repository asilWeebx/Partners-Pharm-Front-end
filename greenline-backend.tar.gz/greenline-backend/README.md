# 🚀 GreenLine Django REST API Backend

Professional backend with Django REST Framework for GreenLine website.

## 📋 Features

- ✅ **Products Management** - Multilingual products (UZ/RU/EN)
- ✅ **Partners Management** - Partner logos and websites
- ✅ **Diseases Management** - Disease categories and products
- ✅ **REST API** - Full CRUD operations
- ✅ **Admin Panel** - Django admin for easy management
- ✅ **Image Upload** - Product and partner logos
- ✅ **Filtering & Search** - Advanced API filtering
- ✅ **CORS Enabled** - Ready for frontend integration

## 🛠️ Setup Instructions

### 1. Create Virtual Environment

```bash
cd greenline-backend
python3 -m venv venv
source venv/bin/activate  # Mac/Linux
# venv\Scripts\activate  # Windows
```

### 2. Install Dependencies

```bash
pip install --upgrade pip
pip install -r requirements.txt
```

### 3. Initialize Django Project

```bash
# Create Django project
django-admin startproject config .

# Create apps
python manage.py startapp products
python manage.py startapp partners
python manage.py startapp diseases
```

### 4. Configure Settings

Copy the contents from `config/settings.py` to your Django settings file.

### 5. Run Migrations

```bash
python manage.py makemigrations
python manage.py migrate
```

### 6. Create Superuser

```bash
python manage.py createsuperuser
# Username: admin
# Email: admin@greenline.uz
# Password: (choose strong password)
```

### 7. Run Server

```bash
python manage.py runserver
```

Server runs at: `http://localhost:8000`

## 📡 API Endpoints

### Products
- `GET /api/products/` - List all products
- `POST /api/products/` - Create product (auth required)
- `GET /api/products/{id}/` - Get product details
- `PUT /api/products/{id}/` - Update product (auth required)
- `DELETE /api/products/{id}/` - Delete product (auth required)

**Query Parameters:**
- `?search=keyword` - Search in name, code, description
- `?category=1` - Filter by category
- `?featured=true` - Featured products only
- `?ordering=-created_at` - Sort by creation date

### Categories
- `GET /api/categories/` - List all categories
- `POST /api/categories/` - Create category (auth required)

### Partners
- `GET /api/partners/` - List all partners
- `POST /api/partners/` - Create partner (auth required)
- `GET /api/partners/{id}/` - Get partner details
- `PUT /api/partners/{id}/` - Update partner (auth required)
- `DELETE /api/partners/{id}/` - Delete partner (auth required)

### Diseases
- `GET /api/diseases/` - List all diseases
- `POST /api/diseases/` - Create disease (auth required)
- `GET /api/diseases/{id}/` - Get disease details
- `PUT /api/diseases/{id}/` - Update disease (auth required)
- `DELETE /api/diseases/{id}/` - Delete disease (auth required)

## 🔐 Admin Panel

Access admin panel at: `http://localhost:8000/admin/`

**Features:**
- ✅ Manage Products (with images)
- ✅ Manage Categories
- ✅ Manage Partners (with logos)
- ✅ Manage Diseases
- ✅ Multilingual content editing
- ✅ Bulk actions
- ✅ Search and filters

## 📁 Project Structure

```
greenline-backend/
├── config/
│   ├── settings.py          # Django settings
│   ├── urls.py              # URL configuration
│   └── wsgi.py              # WSGI config
├── products/
│   ├── models.py            # Product & Category models
│   ├── serializers.py       # API serializers
│   ├── views.py             # API views
│   └── admin.py             # Admin configuration
├── partners/
│   ├── models.py            # Partner model
│   ├── serializers.py       # API serializers
│   └── admin.py             # Admin configuration
├── diseases/
│   ├── models.py            # Disease model
│   ├── serializers.py       # API serializers
│   └── admin.py             # Admin configuration
├── media/                   # Uploaded files
│   ├── products/
│   └── partners/
├── requirements.txt         # Python dependencies
└── manage.py               # Django management
```

## 🌐 CORS Configuration

Frontend URLs allowed:
- `http://localhost:3000` (React dev)
- `http://localhost:5173` (Vite dev)

To add more origins, edit `config/settings.py`:

```python
CORS_ALLOWED_ORIGINS = [
    "http://localhost:3000",
    "http://your-production-domain.com",
]
```

## 📊 Database Models

### Product
- `code` - Unique product code (e.g., SKU-A1-001)
- `name`, `name_ru`, `name_en` - Multilingual names
- `description`, `description_ru`, `description_en` - Descriptions
- `category` - Foreign key to Category
- `image` - Product image
- `is_active` - Visibility status
- `featured` - Featured product flag

### Partner
- `name` - Partner name
- `logo` - Partner logo image
- `website` - Partner website URL
- `description`, `description_ru`, `description_en` - Descriptions
- `order` - Display order
- `is_active` - Visibility status

### Disease
- `title`, `title_ru`, `title_en` - Multilingual titles
- `products`, `products_ru`, `products_en` - Product recommendations
- `order` - Display order
- `is_active` - Visibility status

## 🧪 Testing API

### Using cURL

```bash
# Get all products
curl http://localhost:8000/api/products/

# Get specific product
curl http://localhost:8000/api/products/1/

# Search products
curl "http://localhost:8000/api/products/?search=mahsulot"

# Get all partners
curl http://localhost:8000/api/partners/
```

### Using Postman
Import the API endpoints and test with Postman.

### Using Django REST Framework UI
Visit `http://localhost:8000/api/` for browsable API.

## 🚀 Production Deployment

### Environment Variables

Create `.env` file:

```env
SECRET_KEY=your-secret-key-here
DEBUG=False
ALLOWED_HOSTS=yourdomain.com,www.yourdomain.com
DATABASE_URL=your-database-url
```

### Static & Media Files

```bash
python manage.py collectstatic
```

Configure your web server (Nginx/Apache) to serve:
- `/static/` → `staticfiles/`
- `/media/` → `media/`

## 📝 Next Steps

1. ✅ Backend setup complete
2. ⏳ Create React Admin Dashboard
3. ⏳ Integrate API with frontend
4. ⏳ Deploy to production

---

Made with ❤️ by Asilbek
